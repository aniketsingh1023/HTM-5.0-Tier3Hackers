<?php
function clean($data){
    echo"<pre>";
    print_r($data);
}
?>