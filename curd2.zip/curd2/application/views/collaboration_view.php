<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collaboration Dashboard</title>
    <style>
        /* Reset some basic styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f6f9;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            display: flex;
            background-color: #fff;
            width: 80%;
            max-width: 1200px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar {
            width: 25%;
            background-color: #3c4b64;
            padding: 20px;
            color: #fff;
        }

        .sidebar h2 {
            margin-bottom: 20px;
            font-size: 1.5em;
            text-align: center;
        }

        .department {
            margin-bottom: 20px;
        }

        .department h3 {
            font-size: 1.2em;
            margin-bottom: 10px;
        }

        .department ul {
            list-style: none;
            padding-left: 0;
        }

        .department li {
            padding: 10px;
            background-color: #556080;
            margin-bottom: 8px;
            border-radius: 5px;
            cursor: grab;
            color: #fff;
        }

        .department li:hover {
            background-color: #404a5e;
        }

        .main-area {
            width: 75%;
            padding: 30px;
            background-color: #f9f9fb;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .main-area h2 {
            margin-bottom: 20px;
            color: #333;
            font-size: 1.8em;
        }

        .new-members {
            background-color: #ffffff;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .new-members h3 {
            margin-bottom: 10px;
            font-size: 1.3em;
        }

        .new-member {
            background-color: #f1f2f6;
            padding: 20px;
            border-radius: 10px;
            min-height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
        }

        .new-member p {
            margin: 10px;
            background-color: #ccc;
            padding: 10px;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .remove-button {
            background-color: #ff4d4d;
            color: white;
            border: none;
            padding: 5px;
            cursor: pointer;
            margin-left: 10px;
            border-radius: 3px;
        }

        .messaging {
            background-color: #ffffff;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
        }

        .messaging h3 {
            margin-bottom: 10px;
            font-size: 1.3em;
        }

        #messages {
            height: 200px;
            overflow-y: auto;
            background-color: #f9f9fb;
            padding: 10px;
            border: 1px solid #ddd;
            margin-bottom: 15px;
            border-radius: 10px;
        }

        #messages p {
            margin-bottom: 10px;
            padding: 10px;
            background-color: #e3e6ed;
            border-radius: 5px;
        }

        form {
            display: flex;
            margin-bottom: 15px;
        }

        form input {
            flex-grow: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-right: 10px;
        }

        form button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        form button:hover {
            background-color: #0056b3;
        }

        .video-call-button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .video-call-button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>Departments</h2>
            <?php foreach ($employees as $department => $emp_list): ?>
                <div class="department" id="<?= strtolower(str_replace(' ', '-', $department)) ?>">
                    <h3><?= $department ?> Dept.</h3>
                    <ul>
                        <?php foreach ($emp_list as $employee): ?>
                            <li class="employee" draggable="true"><?= $employee ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="main-area">
            <h2>Collaboration Area</h2>
            <div class="new-members">
                <h3>New Members</h3>
                <div class="new-member" id="new-member" ondrop="drop(event)" ondragover="allowDrop(event)">
                    <p>Drag employees here to collaborate</p>
                </div>
            </div>

            <div class="messaging">
                <h3>Messaging</h3>
                <div id="messages">
                    <?php if (!empty($messages)): ?>
                        <?php foreach ($messages as $msg): ?>
                            <p><?= $msg['message'] ?> (<?= date('H:i', strtotime($msg['timestamp'])) ?>)</p>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No messages yet.</p>
                    <?php endif; ?>
                </div>
                <form method="post" action="<?= base_url('collaboration/send_message') ?>">
                    <input type="text" name="message" id="messageInput" placeholder="Type a message..." required>
                    <button type="submit" id="sendMessage">Send</button>
                </form>
                <button class="video-call-button" onclick="startVideoCall()">Video Call</button>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('.employee').forEach(emp => {
            emp.addEventListener('dragstart', drag);
        });

        function allowDrop(event) {
            event.preventDefault();
        }

        function drag(event) {
            event.dataTransfer.setData('text', event.target.innerText);
        }

        function drop(event) {
            event.preventDefault();
            const data = event.dataTransfer.getData('text');
            const newMember = document.createElement('p');
            newMember.textContent = data;

            const removeButton = document.createElement('button');
            removeButton.textContent = 'Remove';
            removeButton.className = 'remove-button';
            removeButton.onclick = function () {
                newMember.remove();
            };

            newMember.appendChild(removeButton);
            document.getElementById('new-member').appendChild(newMember);
        }

        function startVideoCall() {
            window.location.href = '<?= base_url('collaboration/start_video_call') ?>';
        }
    </script>
</body>
</html>
