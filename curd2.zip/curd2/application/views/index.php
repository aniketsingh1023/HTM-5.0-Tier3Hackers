<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    
    <!-- Include Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap 5 Icons CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    
    <!-- FontAwesome Icons CDN -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <style>
        /* Custom Navbar */
        .navbar-brand {
            font-size: 1.5rem;
            display: flex;
            align-items: center;
        }
        .navbar-brand i {
            margin-right: 10px;
        }

        .navbar-nav .nav-item {
            margin-left: 1rem;
        }

        .navbar-nav .nav-item .nav-link {
            display: flex;
            align-items: center;
        }

        .navbar-nav .nav-item .nav-link i {
            margin-right: 5px;
        }

        /* Sidebar */
        .sidebar {
            height: 100vh;
            width: 250px;
            background-color: #343a40;
            position: fixed;
            top: 0;
            left: 0;
            overflow-y: auto;
            color: white;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            display: block;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .sidebar hr {
            background-color: white;
        }

        /* Product Table */
        .table {
            margin-top: 20px;
        }

        .table thead {
            background-color: #f8f9fa;
        }

        .table-hover tbody tr:hover {
            background-color: #f1f1f1;
        }

        /* Cards for Products */
        .product-card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease-in-out;
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        /* Button Styles */
        .btn-custom {
            background-color: #007bff;
            color: white;
            transition: background-color 0.3s ease;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container-fluid">
            <!-- Brand -->
            <a class="navbar-brand" href="#">
                <i class="bi bi-box-seam"></i> CROMA
            </a>

            <!-- Toggler button for mobile view -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <!-- Home -->
                    <li class="nav-item">
                        <a class="nav-link active px-3" href="<?php echo base_url('home'); ?>">
                            <i class="bi bi-house-door"></i> Home
                        </a>
                    </li>

                    <!-- Add Product -->
                    <li class="nav-item">
                        <a class="nav-link active px-3" href="<?php echo base_url('products/create'); ?>">
                            <i class="bi bi-plus-circle"></i> Add Product
                        </a>
                    </li>

                    <!-- Franchise Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link active dropdown-toggle px-3" href="#" id="categoriesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-tags"></i> Franchise
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="categoriesDropdown">
                            <li><a class="dropdown-item" href="#">EAST Delhi</a></li>
                            <li><a class="dropdown-item" href="#">WEST Delhi</a></li>
                            <li><a class="dropdown-item" href="#">SOUTH Delhi</a></li>
                        </ul>
                    </li>

                    <!-- Profile -->
                    <li class="nav-item">
                        <a class="nav-link active px-3" href="<?php echo base_url('products/home'); ?>">
                            <i class="bi bi-person-circle"></i> Profile
                        </a>
                    </li>

                    <!-- Search bar -->
                    <li class="nav-item">
                        <form class="d-flex ms-3">
                            <input class="form-control me-2" type="search" placeholder="Search products..." aria-label="Search">
                            <button class="btn btn-outline-light" type="submit"><i class="bi bi-search"></i></button>
                        </form>
                    </li>

                    <!-- Logout -->
                    <li class="nav-item ms-3">
                        <a class="nav-link active px-3" href="<?php echo base_url('user/logout'); ?>">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Sidebar -->
    <div class="sidebar">
        <a href="#"><i class="fas fa-chart-line"></i> Dashboard</a>
        <hr>
        <a href="#"><i class="fas fa-chart-pie"></i> Prediction</a>
        <a href="#"><i class="fas fa-chart-bar"></i> Statistics</a>
        <a href="<?= base_url('collaboration') ?>"><i class="fas fa-chart-bar"></i> Team collaboration</a>
        <!-- <li class="nav-item dropdown"> -->
                    <a class="nav-link dropdown-toggle px-3" href="#" id="categoriesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-tags"></i> Sales Report
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="categoriesDropdown">
                        <li><a class="dropdown-item" href="<?php echo base_url('reports/sales'); ?>">Today</a></li>
                        <li><a class="dropdown-item" href="#">Last 7 days</a></li>
                        <li><a class="dropdown-item" href="#">Last 30 days</a></li>
                    </ul>
                <!-- </li> -->
        <a href="#"><i class="fas fa-question-circle"></i> FAQs</a>
        <a href="#"><i class="fas fa-cogs"></i> Settings</a>
        <hr>
        <a href="<?php echo base_url('user/logout'); ?>"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <!-- Main content -->
    <div class="container mt-4" style="margin-left: 270px;">
        <?php if ($this->session->flashdata('success_message')): ?>
            <div class="alert alert-success"><?php echo $this->session->flashdata('success_message'); ?></div>
        <?php endif; ?>

        <h1 class="mb-4">All Products</h1>

        <!-- Product Table -->
        <div class="row">
            <?php if (!empty($products)): ?>
                <?php foreach ($products as $product): ?>
                    <div class="col-md-4">
                        <div class="card product-card mb-4">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $product['name']; ?></h5>
                                <p class="card-text"><?php echo $product['discription']; ?></p>
                                <a href="<?php echo base_url('products/details/' . $product['id']); ?>" class="btn btn-custom">Details</a>
                                <a href="<?php echo base_url('products/update/' . $product['id']); ?>" class="btn btn-warning">Update</a>
                                <form action="<?php echo base_url('products/delete/' . $product['id']); ?>" method="post" style="display:inline;">
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No products found.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
